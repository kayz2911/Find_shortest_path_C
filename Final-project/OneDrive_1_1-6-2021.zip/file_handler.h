#ifndef _FILE_HANDLER_H
#define _FILE_HANDLER_H

#include "graph.h"

extern Graph read_db(char *filename, Graph head);

#endif